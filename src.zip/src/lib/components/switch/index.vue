<template>
    <span class="v3-switch-wrap" @click="toggle">
        <input class="v3-switch" type="checkbox" v-model="isShow">
        <i></i>
    </span>
</template>
<script>
export default {
    name: "v3-switch",
    data () {
        return {
            isShow:true
        };
    },
    methods: {
        toggle(){
            this.isShow = !this.isShow;
            this.$emit('change',this.isShow);
        }
    }
}
</script>
<style lang="scss" scoped>
    .v3-switch-wrap {
        display: inline-block;
    }
    input {
        position: absolute;
        left: 999999px;
        & + i {
            width: 48px;
            height: 24px;
            line-height: 22px;
            border-radius: 24px;
            vertical-align: middle;
            border: 1px solid #ccc;
            background-color: #ccc;
            position: relative;
            cursor: pointer;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            transition: all .3s ease-in-out;
            display: inline-block;
            &:before {
                content: "";
                width: 20px;
                height: 20px;
                border-radius: 20px;
                background: #ccc;
                position: absolute;
                left: 1px;
                top: 1px;
                cursor: pointer;
                transition: left .3s ease-in-out,width .3s ease-in-out;
            }
        }
        &:checked + i{
            background: #4cd864;
            &:before {
                left: 25px;
            }
        }
    }
</style>
<template>
  <div id="app">
    <v3-button
      class="aaa"
      :style-object = proporty
      @click = aaa>
      按钮
    </v3-button>
   	
	<br>
	
	<div>已选中：{{checkList}}</div>

    <div style="padding:10px; display:none;">
      	<v3-cell-item type="checkbox">
            <img  slot="icon" src="http://static.ydcss.com/ydui/img/logo.png">			  
            <span slot="left">多选一</span>
            <input slot="right" type="checkbox" value="1" v-model="checkList"/>            
        </v3-cell-item>
        <v3-cell-item type="checkbox">
            <span slot="left">多选二</span>
            <input slot="right" type="checkbox" value="2" v-model="checkList"/>            
        </v3-cell-item>
        <v3-cell-item type="checkbox">
                <span slot="left">多选二</span>
                <input slot="right" type="checkbox" value="3" v-model="checkList"/>            
            </v3-cell-item>
        <v3-cell-item type="checkbox">
                <span slot="left">多选二</span>
                <input slot="right" type="checkbox" value="4" v-model="checkList"/>            
        </v3-cell-item>
    </div>

    <div style="padding:10px">
        <v3-cell-item type="radio" href = "xxxx">
            <img  slot="icon" src="http://static.ydcss.com/ydui/img/logo.png">
            <span slot="left">选项一</span>
            <input slot="right" type="radio" value="Han MeiMei" v-model="picked"/>
        </v3-cell-item>
        <v3-cell-item type="radio">
            <span slot="left">选项二</span>
            <input slot="right" type="radio" value="MeiM" v-model="picked"/>            
        </v3-cell-item>
    </div>
    <div>
        <v3-switch color="#ff4747" @change = "abc">
          <span slot="open">开</span>
          <span slot="close">关</span>
        </v3-switch>

        <v3-switch color="#ff4747">
          <span slot="open">开</span>
          <span slot="close">关</span>
        </v3-switch>

    </div>
  </div>
</template>

<!--
  1. isLoading是否显示loading图片
  2. style-object 传入样式对象，如proporty
    proporty: {
      color: '#fff',
      background: '#ff4747',
      borderRadius: '10px'
    }
  3. @click  button的点击触发事件
  4. disabled 是否需要禁止点击 设置该属性后 点击事件失效
-->

<script>

export default {
  name: 'app',
  data () {
    return {
      //少量的样式修改支出直接定制
      proporty: {
        // color: '#fff',
        // background: '#ff4747',
        // borderRadius: '10px'
      },
      link: '123123',
      picked: 'MeiM',
      checkList:[],
      switch1: false
    }
  },
  methods: {
    aaa(){
      console.log('点我');
    },
    abc(val){
        console.log(val);
    }
  }
}
</script>

<style lang="scss">
@import './lib/components/styles/common/reset.scss';
* {
    margin: 0;
    padding: 0;
}
html,body {
    background: #f5f5f5;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
